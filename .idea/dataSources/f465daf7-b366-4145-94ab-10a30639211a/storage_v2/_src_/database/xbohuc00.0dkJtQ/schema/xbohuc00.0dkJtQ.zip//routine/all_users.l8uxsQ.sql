create procedure all_users(IN numeric, IN character varying)
    language plpgsql
as
$$
BEGIN
SELECT * FROM xbohuc00.users;
END;
$$;

alter procedure all_users(numeric, varchar) owner to postgres;

