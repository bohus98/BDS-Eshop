create materialized view shop_submission as
SELECT shop.shop_name,
       count(*) AS count
FROM xbohuc00.shop
         JOIN xbohuc00.blocked_shops ON blocked_shops.shop_id = shop.shop_id
         JOIN xbohuc00.product ON product.shop_id = shop.shop_id
WHERE shop.shop_id = 1
GROUP BY shop.shop_name
HAVING count(*) < 10;

alter materialized view shop_submission owner to postgres;

