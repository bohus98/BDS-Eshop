create view product_price(product_name, price) as
SELECT product.product_name,
       product.price
FROM xbohuc00.product
WHERE product.has_price = 1;

alter table product_price
    owner to postgres;

grant delete, insert, select, update on product_price to teacher;

