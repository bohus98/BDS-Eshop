create procedure all_users(IN numeric, IN character varying)
    language plpgsql
as
$$
BEGIN
SELECT * FROM users;
END;
$$;

alter procedure all_users(numeric, varchar) owner to postgres;

