create procedure insert_user(IN numeric, IN character varying, IN character varying, IN character varying, IN character varying)
    language plpgsql
as
$$
BEGIN
INSERT INTO xbohuc00.users(user_id,user_name,email,account_name,account_password) VALUES ($1,$2,$3,$4,$5);
END;
$$;

alter procedure insert_user(numeric, varchar, varchar, varchar, varchar) owner to postgres;

